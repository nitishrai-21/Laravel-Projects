<?php $__env->startSection('content'); ?>
        <div class="jumbotron text-center">
                <h1><?php echo e($title); ?></h1>


                <a href="/deals" style="background-color:orange;color:white;" class="btn btn-default btn-lg">Click to see todays best deal</a>
                
        </div>
        
        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingwebsite\resources\views/pages/index.blade.php ENDPATH**/ ?>