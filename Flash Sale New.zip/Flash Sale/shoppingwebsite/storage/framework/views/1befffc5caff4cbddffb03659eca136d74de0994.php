<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
<?php $__env->startSection('content'); ?>
    
        <table id="customers">
            <tr>
                <th>product</th>
                <th>Title</th>
                <th>Description</th>
                <th>Amount to Pay</th>
            </tr>
            <tr>
                <td><img style="width:100px;height:100px;" src="/storage/images/<?php echo e($deal->image); ?>" alt="image of the product"></td>
                <td><?php echo e($deal->title); ?></td>
                <td><?php echo e($deal->description); ?></td>
                <td><?php echo e($cost); ?></td>
            </tr>    
        </table>
        <p>Click on the button below to confirm your order</p>
           <?php if(!Auth::guest()): ?>
            <?php echo Form::open(['action'=> ['DealsController@update',$deal->id], 'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method','PUT')); ?>

                <?php echo e(Form::submit('Confirm Your Order',['class'=>'btn btn-success'])); ?>

            <?php echo e(Form::close()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


 
       

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingwebsite\resources\views/deals/confirmation.blade.php ENDPATH**/ ?>