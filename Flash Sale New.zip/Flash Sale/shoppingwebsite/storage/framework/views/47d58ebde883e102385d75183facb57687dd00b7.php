<?php $__env->startSection('content'); ?>
        <h1><?php echo e($deal->title); ?></h1>
        <p>This is Conformation Page</p>
           <?php if(!Auth::guest()): ?>
            <?php echo Form::open(['action'=> ['DealsController@update',$deal->id], 'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method','PUT')); ?>

                <?php echo e(Form::submit('Confirm',['class'=>'btn btn-success'])); ?>

            <?php echo e(Form::close()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


 
       

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingwebsite\resources\views/deals/edit.blade.php ENDPATH**/ ?>