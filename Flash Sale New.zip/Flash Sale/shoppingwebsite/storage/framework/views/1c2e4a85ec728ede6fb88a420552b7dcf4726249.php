<?php $__env->startSection('content'); ?>
    <h1>Deal For Today</h1>
            <?php if(count($deals) > 0 && $quantity_left > 0): ?>
                <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal_var): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="well">
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <img style="width:100%;" src="/storage/images/<?php echo e($deal_var->image); ?>" alt="image of the product">
                            </div>
                            <div class="col-md-8 col-sm-8">
                                <h3><a href="#"><?php echo e($deal_var->title); ?></a></h3>
                                <small>Description: <?php echo e($deal_var->description); ?></small>
                                <h5>Original Price: <?php echo e($deal_var->price); ?></h5>
                                <h5>discounted Price:<?php echo e($deal_var->discounted_price); ?></h5>
                                <?php if($cost != 0): ?>
                                    <h4>Price only For you: <?php echo e($cost); ?></h4>
                                <?php endif; ?>
                                <h3 style="color: red;">Hurry up only <?php echo e($quantity_left); ?> quantity left</h3>
                                <a href="/deals/<?php echo e($deal_var->id); ?>/confirmation" class="btn btn-success">Buy Now</a>
                            </div>
                        </div>    
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p> No deals available </p>
            <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingwebsite\resources\views/deals/index.blade.php ENDPATH**/ ?>