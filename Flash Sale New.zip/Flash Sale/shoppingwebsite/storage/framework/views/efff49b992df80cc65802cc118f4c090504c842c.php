<?php $__env->startSection('content'); ?>

    <h1> Create Post</h1>
    <?php echo Form::open(['action'=> 'DealsController@store', 'method' => 'POST', 'enctype'=> 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('title', 'Title')); ?>

            <?php echo e(Form::text('title','',['class' => 'form-control','placeholder'=>'Title'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('description', 'Description')); ?>

            <?php echo e(Form::textarea('description','',['class' => 'form-control','placeholder'=>'Description Text'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('price', 'Price')); ?>

            <?php echo e(Form::text('price','',['class' => 'form-control','placeholder'=>'Price should be a positive integer'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('discounted_price', 'Discount Price')); ?>

            <?php echo e(Form::text('discounted_price','',['class' => 'form-control','placeholder'=>'Discount Price should be a positive integer'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('quantity', 'Quantity')); ?>

            <?php echo e(Form::text('quantity','',['class' => 'form-control','placeholder'=>'Quantity should be a positive integer'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('publish_date', 'Publish Date')); ?>

            <?php echo e(Form::text('publish_date','',['id' => 'datepicker','class' => 'form-control','placeholder'=>'Publish Date'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::file('image')); ?>

        </div>
        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingwebsite\resources\views/deals/create.blade.php ENDPATH**/ ?>