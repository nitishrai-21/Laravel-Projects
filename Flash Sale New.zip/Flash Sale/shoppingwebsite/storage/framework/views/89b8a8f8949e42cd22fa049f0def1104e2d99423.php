<?php $__env->startSection('content'); ?>
        <h1><?php echo e($title); ?></h1>
        <p>This is About Page</p>
           <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $deals->user_id): ?>
            <?php echo Form::open(['action'=> ['DealsController@update',$deals->id], 'method' => 'POST']); ?>

                
                <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger'])); ?>

            <?php echo e(Form::close()); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingwebsite\resources\views/pages/about.blade.php ENDPATH**/ ?>