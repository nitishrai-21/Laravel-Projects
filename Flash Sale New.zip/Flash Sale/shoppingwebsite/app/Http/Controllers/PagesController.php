<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index(){
        $title= 'Welcome to FlashSale !';
       return view('pages.index')->with('title',$title); 
    }
    
    public function unauthorised(){
       return view('pages.unauthorised')->with($data); 
    }
}
