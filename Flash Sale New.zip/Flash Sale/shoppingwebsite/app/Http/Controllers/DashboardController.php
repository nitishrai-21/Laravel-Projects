<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use APP\User;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        if($user_id==1)
        {
            return view('dashboard')->with('deals', $user->deals);
        }
        else{
            $title = "Welcome to FlashSale !";
            return view('pages.index')->with('title', $title);
        }
       
    }
}
