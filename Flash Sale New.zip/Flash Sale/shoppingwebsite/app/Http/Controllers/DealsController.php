<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Support\Collection;
use Illuminate\Http\Request;
use App\Deal;
use App\User;
use Carbon;

class DealsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Auth::guest()){

            $newCollection = collect();
            $newCollection=$this->getTimeValidation();
            $cost= $this->discountCalulate($newCollection[1]);

            return view('deals.index')->with('deals', $newCollection[0])->with('cost',$cost)->with('quantity_left',$newCollection[2]);
        }else{
            return view('auth.login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!Auth::guest()){
            if(Auth::user()->id == 1){
                return view('deals.create');
            }else{
                return view('pages.unauthorised');
            }
        }else{
            return view('auth.login');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!Auth::guest()){
            if(Auth::user()->id == 1){
                $this->validate($request,[
                    'title' => 'required',
                    'description' => 'required',
                    'price' => ['required','integer','not_in:0', 'regex:/[0-9]([0-9]|-(?!-))+/'],
                    'discounted_price' => ['required','integer','not_in:0', 'regex:/[0-9]([0-9]|-(?!-))+/','lte:price'],
                    'quantity' => ['required','integer','not_in:0', 'regex:/[0-9]([0-9]|-(?!-))+/'],
                    'publish_date' => 'required',
                    'image' => 'image|mimes:jpeg,png|required|max:1999'
                ]);
                if($request->hasFile('image')){
                    $fileNamewithExt = $request->file('image')->getClientOriginalName();
                    $fileName = pathinfo($fileNamewithExt, PATHINFO_FILENAME);
                    $extensuion = $request->file('image')->getClientOriginalExtension();
                    $fileNameToStore = $fileName.'_'.time().'.'.$extensuion;
                    $path = $request->file('image')->storeAs('public/images',$fileNameToStore);
                }

                $deal= new Deal;
                $deal->title = $request->input('title');
                $deal->description = $request->input('description');
                $deal->price = $request->input('price');
                $deal->discounted_price = $request->input('discounted_price');
                $deal->quantity = $request->input('quantity');
                $deal->publish_date = $request->input('publish_date');
                $deal->image = $fileNameToStore;
                $deal->save();
                return redirect('/deals')->with('success', 'Deal Added');
            }else{
                return view('pages.unauthorised');
            }
        }else{
            return view('auth.login');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getTimeValidation()
    {
        $string = Carbon::now('Asia/Kolkata')->toDateTimeString();
        $splitter = " ";
        $splitter_another = ":";
        $pieces = explode($splitter, $string);
        $pieces = explode($splitter_another, $pieces[1]);
        $date_time = $pieces[0];
        if($date_time >= 10){
            $quantity_left = Deal::where('publish_date', Carbon::today())->where('quantity','>', '0')->limit(1)->value('quantity');
            $deals= Deal::where('publish_date', Carbon::today())->where('quantity','>', '0')->limit(1)->get();
            $cost = Deal::where('publish_date', Carbon::today())->where('quantity','>', '0')->value('discounted_price');
        }else{
            $quantity_left = Deal::where('publish_date', Carbon::today())->limit(1)->value('quantity');
            $deals= Deal::where('publish_date', Carbon::yesterday())->where('quantity','>', '0')->limit(1)->get();
            $cost = Deal::where('publish_date', Carbon::yesterday())->where('quantity','>', '0')->value('discounted_price');
        }

        $newCollection = collect([$deals, $cost, $quantity_left, $date_time]);
        return $newCollection;
    }

    /**
     * Show the form for confirmation the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function confirmation($id)
    {
        if(!Auth::guest()){
            $deal = Deal::find($id);
            $newCollection = collect();
            $newCollection=$this->getTimeValidation();
            $cost= $this->discountCalulate($newCollection[1]);

            return view('deals.confirmation')->with('deal', $deal)->with('cost',$cost)->with('quantity_left',$newCollection[2]);
        }else{
            return view('auth.login');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(!Auth::guest()){
            $deal= Deal::find($id);
            $date = Deal::where('id',$id)->value('publish_date');
            $date = Carbon::parse($date);
            $today = Carbon::today();
            $diff=$date->diffInDays($today,false);
            $newCollection=$this->getTimeValidation();
            if(($diff == 0 && $newCollection[3] >= 10) || ($diff == 1 && $newCollection[3] < 10 ))
            {
                $total_quantity = $deal->quantity;
                $quantity_left = $total_quantity-1;
                $deal->quantity = $quantity_left;
                $deal->save();
                
                $user_id = Auth::user()->id;
                $user= User::find($user_id);
                $visit = User::where('id',$user_id)->value('visits');
                $visits= $visit+1;
                $user->visits = $visits;
                $user->save();
                
                return redirect('/')->with('success', 'Your order has been Placed');
            }else{
                return view('pages.unauthorised');
            }
        }else{
            return view('auth.login');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function discountCalulate($cost)
    {
            $user_id = Auth::user()->id;
            $user= User::find($user_id);
            $countt=  User::where('id',$user_id)->value('visits');
            if($countt>=1 && $countt<=5){
            $discount = $cost * ($countt/100);
            $cost= $cost - $discount;
            }elseif($countt>5){
                $discount = $cost * (5/100);
                $cost= $cost - $discount;
            }
            return $cost;
    }
}
