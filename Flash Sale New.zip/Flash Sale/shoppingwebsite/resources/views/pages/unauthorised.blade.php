@extends('layouts.app')

@section('content')
        <h1><center>You are not authorised to access this page</center></h1>
@endsection
