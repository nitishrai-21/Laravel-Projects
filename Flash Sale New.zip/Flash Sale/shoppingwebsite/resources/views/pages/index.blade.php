@extends('layouts.app')

@section('content')
        <div class="jumbotron text-center">
                <h1>{{$title}}</h1>


                <a href="/deals" style="background-color:orange;color:white;" class="btn btn-default btn-lg">Click to see todays best deal</a>
                
        </div>
        
        
@endsection
