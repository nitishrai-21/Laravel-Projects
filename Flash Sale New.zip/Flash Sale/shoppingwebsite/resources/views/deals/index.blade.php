@extends('layouts.app')

@section('content')
    <h1>Deal For Today</h1>
            @if(count($deals) > 0 && $quantity_left > 0)
                @foreach ($deals as $deal_var )
                    <div class="well">
                        <div class="row">
                            <div class="col-md-4 col-sm-4">
                                <img style="width:100%;" src="/storage/images/{{$deal_var->image}}" alt="image of the product">
                            </div>
                            <div class="col-md-8 col-sm-8">
                                <h3><a href="#">{{$deal_var->title}}</a></h3>
                                <small>Description: {{$deal_var->description}}</small>
                                <h5>Original Price: {{$deal_var->price}}</h5>
                                <h5>discounted Price:{{$deal_var->discounted_price}}</h5>
                                @if($cost != 0)
                                    <h4>Price only For you: {{$cost}}</h4>
                                @endif
                                <h3 style="color: red;">Hurry up only {{$quantity_left}} quantity left</h3>
                                <a href="/deals/{{$deal_var->id}}/confirmation" class="btn btn-success">Buy Now</a>
                            </div>
                        </div>    
                    </div>
                @endforeach
            @else
                <p> No deals available </p>
            @endif
@endsection