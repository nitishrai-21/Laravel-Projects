@extends('layouts.app')
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
@section('content')
    
        <table id="customers">
            <tr>
                <th>product</th>
                <th>Title</th>
                <th>Description</th>
                <th>Amount to Pay</th>
            </tr>
            <tr>
                <td><img style="width:100px;height:100px;" src="/storage/images/{{$deal->image}}" alt="image of the product"></td>
                <td>{{$deal->title}}</td>
                <td>{{$deal->description}}</td>
                <td>{{$cost}}</td>
            </tr>    
        </table>
        <p>Click on the button below to confirm your order</p>
           @if(!Auth::guest())
            {!! Form::open(['action'=> ['DealsController@update',$deal->id], 'method' => 'POST']) !!}
                {{Form::hidden('_method','PUT')}}
                {{Form::submit('Confirm Your Order',['class'=>'btn btn-success'])}}
            {{ Form::close() }}
    @endif
@endsection


 
       
