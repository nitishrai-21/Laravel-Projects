@extends('layouts.app')


@section('content')

    <h1> Create Post</h1>
    {!! Form::open(['action'=> 'DealsController@store', 'method' => 'POST', 'enctype'=> 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('title', 'Title')}}
            {{Form::text('title','',['class' => 'form-control','placeholder'=>'Title'])}}
        </div>
        <div class="form-group">
            {{Form::label('description', 'Description')}}
            {{Form::textarea('description','',['class' => 'form-control','placeholder'=>'Description Text'])}}
        </div>
        <div class="form-group">
            {{Form::label('price', 'Price')}}
            {{Form::text('price','',['class' => 'form-control','placeholder'=>'Price should be a positive integer'])}}
        </div>
        <div class="form-group">
            {{Form::label('discounted_price', 'Discount Price')}}
            {{Form::text('discounted_price','',['class' => 'form-control','placeholder'=>'Discount Price should be a positive integer'])}}
        </div>
        <div class="form-group">
            {{Form::label('quantity', 'Quantity')}}
            {{Form::text('quantity','',['class' => 'form-control','placeholder'=>'Quantity should be a positive integer'])}}
        </div>
        <div class="form-group">
            {{Form::label('publish_date', 'Publish Date')}}
            {{Form::text('publish_date','',['id' => 'datepicker','class' => 'form-control','placeholder'=>'Publish Date'])}}
        </div>
        <div class="form-group">
            {{Form::file('image')}}
        </div>
        {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
    {{ Form::close() }}
@endsection